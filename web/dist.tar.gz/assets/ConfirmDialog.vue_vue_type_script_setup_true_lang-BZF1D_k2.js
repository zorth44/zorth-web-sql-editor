import{c as l,d as p,r as b,H as h,o as k,I as v,b as g,e as a,t as r,D as w,E as B,m as D,ah as S,n as c,aa as x}from"./index-6moDn6S2.js";/**
 * @license lucide-vue-next v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $=l("PencilIcon",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]]);/**
 * @license lucide-vue-next v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=l("PlusIcon",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);/**
 * @license lucide-vue-next v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=l("SearchIcon",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);/**
 * @license lucide-vue-next v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=l("Trash2Icon",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]),C={id:"dialog-title",class:"text-lg font-semibold"},E={class:"mt-4"},I={class:"mt-6 flex justify-end gap-3"},M=["disabled"],T=["disabled"],V=p({__name:"ConfirmDialog",props:{open:{type:Boolean},title:{},busy:{type:Boolean,default:!1},confirmDisabled:{type:Boolean,default:!1},tone:{default:"danger"},confirmLabel:{default:"确认"}},emits:["close","confirm"],setup(u,{emit:f}){const d=u,y=f,o=b(null);let n=null;h(()=>d.open,async e=>{e?(n=document.activeElement,await x(),o.value?.querySelector("input,button")?.focus()):n?.focus()}),k(()=>n?.focus());function m(e){if(e.key==="Escape"&&!d.busy&&y("close"),e.key!=="Tab"||!o.value)return;const t=[...o.value.querySelectorAll("button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href]")],s=t[0],i=t.at(-1);!s||!i||(e.shiftKey&&document.activeElement===s?(e.preventDefault(),i.focus()):!e.shiftKey&&document.activeElement===i&&(e.preventDefault(),s.focus()))}return(e,t)=>(c(),v(S,{to:"body"},[e.open?(c(),g("div",{key:0,class:"fixed inset-0 z-40 grid place-items-center bg-overlay p-6",onKeydown:m},[a("section",{ref_key:"panel",ref:o,class:"w-full max-w-md rounded-xl bg-panel p-6 shadow-2xl",role:"dialog","aria-modal":"true","aria-labelledby":"dialog-title"},[a("h2",C,r(e.title),1),a("div",E,[w(e.$slots,"default")]),a("div",I,[a("button",{class:"btn",type:"button",disabled:e.busy,onClick:t[0]||(t[0]=s=>e.$emit("close"))},"取消",8,M),a("button",{class:B(e.tone==="primary"?"btn-primary":"btn-danger"),type:"button",disabled:e.busy||e.confirmDisabled,onClick:t[1]||(t[1]=s=>e.$emit("confirm"))},r(e.busy?"处理中…":e.confirmLabel),11,T)])],512)],32)):D("",!0)]))}});export{q as P,z as S,L as T,V as _,$ as a};
